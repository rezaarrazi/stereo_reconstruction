def softmax(input: Tensor,
    dim: Optional[int]=None,
    _stacklevel: int=3,
    dtype: Optional[int]=None) -> Tensor:
  _0 = __torch__.torch.nn.functional._get_softmax_dim
  if torch.__is__(dim, None):
    dim1 = _0("softmax", torch.dim(input), _stacklevel, )
    dim0 = dim1
  else:
    dim0 = unchecked_cast(int, dim)
  if torch.__is__(dtype, None):
    ret = torch.softmax(input, dim0)
  else:
    dtype0 = unchecked_cast(int, dtype)
    ret = torch.softmax(input, dim0, dtype0)
  return ret
def normalize(input: Tensor,
    p: float=2.,
    dim: int=1,
    eps: float=9.9999999999999998e-13,
    out: Optional[Tensor]=None) -> Tensor:
  if torch.__is__(out, None):
    _2 = torch.clamp_min(torch.norm(input, p, [dim], True), eps)
    denom = torch.expand_as(_2, input)
    _1 = torch.div(input, denom)
  else:
    out0 = unchecked_cast(Tensor, out)
    _3 = torch.clamp_min_(torch.norm(input, p, [dim], True), eps)
    denom0 = torch.expand_as(_3, input)
    _1 = torch.div(input, denom0, out=out0)
  return _1
def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    result = torch.relu_(input)
  else:
    result = torch.relu(input)
  return result
def _max_pool2d(input: Tensor,
    kernel_size: List[int],
    stride: Optional[List[int]]=None,
    padding: List[int]=[0, 0],
    dilation: List[int]=[1, 1],
    ceil_mode: bool=False,
    return_indices: bool=False) -> Tensor:
  _4 = "Note that order of the arguments: ceil_mode and return_indices will changeto match the args list in nn.MaxPool2d in a future release."
  if torch.ne(ceil_mode, return_indices):
    torch.warn(_4)
  else:
    pass
  if torch.__is__(stride, None):
    stride0 = annotate(List[int], [])
  else:
    stride0 = unchecked_cast(List[int], stride)
  _5 = torch.max_pool2d(input, kernel_size, stride0, padding, dilation, ceil_mode)
  return _5
def _get_softmax_dim(name: str,
    ndim: int,
    stacklevel: int) -> int:
  _6 = "Implicit dimension choice for {} has been deprecated. Change the call to include dim=X as an argument."
  torch.warn(torch.format(_6, name), stacklevel)
  if torch.eq(ndim, 0):
    _7 = True
  else:
    _7 = torch.eq(ndim, 1)
  if _7:
    _8 = True
  else:
    _8 = torch.eq(ndim, 3)
  if _8:
    ret = 0
  else:
    ret = 1
  return ret
def grid_sample(input: Tensor,
    grid: Tensor,
    mode: str="bilinear",
    padding_mode: str="zeros",
    align_corners: Optional[bool]=None) -> Tensor:
  _9 = "nn.functional.grid_sample(): expected mode to be \'bilinear\', \'nearest\' or \'bicubic\', but got: \'{}\'"
  _10 = "nn.functional.grid_sample(): expected padding_mode to be \'zeros\', \'border\', or \'reflection\', but got: \'{}\'"
  _11 = "Default grid_sample and affine_grid behavior has changed to align_corners=False since 1.3.0. Please specify align_corners=True if the old behavior is desired. See the documentation of grid_sample for details."
  if torch.ne(mode, "bilinear"):
    _12 = torch.ne(mode, "nearest")
  else:
    _12 = False
  if _12:
    _13 = torch.ne(mode, "bicubic")
  else:
    _13 = False
  if _13:
    ops.prim.RaiseException(torch.format(_9, mode))
  else:
    pass
  if torch.ne(padding_mode, "zeros"):
    _14 = torch.ne(padding_mode, "border")
  else:
    _14 = False
  if _14:
    _16 = torch.ne(padding_mode, "reflection")
    _15 = _16
  else:
    _15 = False
  if _15:
    ops.prim.RaiseException(torch.format(_10, padding_mode))
  else:
    pass
  if torch.eq(mode, "bilinear"):
    mode_enum = 0
  else:
    if torch.eq(mode, "nearest"):
      mode_enum0 = 1
    else:
      mode_enum0 = 2
    mode_enum = mode_enum0
  if torch.eq(padding_mode, "zeros"):
    padding_mode_enum = 0
  else:
    if torch.eq(padding_mode, "border"):
      padding_mode_enum0 = 1
    else:
      padding_mode_enum0 = 2
    padding_mode_enum = padding_mode_enum0
  if torch.__is__(align_corners, None):
    torch.warn(_11)
    align_corners0 = False
  else:
    align_corners0 = unchecked_cast(bool, align_corners)
  _17 = torch.grid_sampler(input, grid, mode_enum, padding_mode_enum, align_corners0)
  return _17
